import React, { useState } from 'react';
import axios from 'axios';
import './App.css';

function App() {
  const [query, setQuery] = useState('SELECT * FROM employees;');
  const [results, setResults] = useState([]);
  const [error, setError] = useState('');

  const runQuery = async () => {
    setError('');
    try {
      const response = await axios.post('http://localhost:5000/execute', { query });
      setResults(response.data);
    } catch (err) {
      setError(err.response?.data?.error || 'Execution failed');
      setResults([]);
    }
  };

  return (
    <div className="App">
      <header className="header">
        <h1>CipherSQLStudio</h1>
      </header>

      <main className="container">
        <div className="question-panel">
          <h2>Assignment: Fetch All Staff</h2>
          <p>Write a query to display all columns for every employee in the table.</p>
        </div>

        <div className="editor-panel">
          <textarea 
            value={query} 
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Type your SQL here..."
          />
          <button onClick={runQuery}>Run Query</button>
        </div>

        {error && <div className="error-box">{error}</div>}

        <div className="results-panel">
          {results.length > 0 ? (
            <table>
              <thead>
                <tr>
                  {Object.keys(results[0]).map(key => <th key={key}>{key}</th>)}
                </tr>
              </thead>
              <tbody>
                {results.map((row, i) => (
                  <tr key={i}>
                    {Object.values(row).map((val, j) => <td key={j}>{val}</td>)}
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <p>No results to show. Run a query!</p>
          )}
        </div>
      </main>
    </div>
  );
}

export default App;